#!/bin/bash
gcc server.c -o server
gcc client.c -o client
chmod 777 *