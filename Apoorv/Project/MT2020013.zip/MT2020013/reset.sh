#!/bin/bash
rm *.dat
rm server client