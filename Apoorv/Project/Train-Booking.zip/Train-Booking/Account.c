struct Account
{
    char username[1024];
    char password[1024];
    int type;
    char status[1024];
    int session;
};
