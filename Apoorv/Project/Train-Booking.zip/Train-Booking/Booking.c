struct Booking{
    char Tnumber[1024];
    char Anumber[1024];
    char status[1024];
    int  seats;
    int Bnumber;
};
