struct Train
{
    char number[1024];
    char name[1024];
    int total_seats;
    int booked_seats;
    char status[1024];
};
