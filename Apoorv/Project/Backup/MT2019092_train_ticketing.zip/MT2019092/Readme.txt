
#port 8888

FIRST COMPILE BOTH CLIENT AND SERVER USING FOLLOWING COMMANDS
FOR SERVER
	$ gcc server.c -o server1
	
FOR CLIENT 
	$ gcc client.c -o client1

FOR RUNNING THE SERVER:
	$./server1

FOR RUNNING THE CLIENT
	$./client1 ipaddress portno

1. first sign up and create one admin account. 

2. now login into admin account and add trains.

3. create customers account and login to book ticket and perform other operations.

4. create agents account and login to book ticket and perform other operations.


